<?php
ob_start();

if ((isset($_POST['fname'])) && (strlen(trim($_POST['fname'])) > 0)) {
	 $fname = stripslashes(strip_tags($_POST['fname']));
} else {$fname = 'First Name not entered';}

if ((isset($_POST['lname'])) && (strlen(trim($_POST['lname'])) > 0)) {
	 $lname= stripslashes(strip_tags($_POST['lname']));
} else {$lname = 'Last Name not entered';}

if ((isset($_POST['email'])) && (strlen(trim($_POST['email'])) > 0)) {
	 $email = stripslashes(strip_tags($_POST['email']));
} else {$email = 'Email not entered';}

if ((isset($_POST['phone'])) && (strlen(trim($_POST['phone'])) > 0)) {
	$phone = stripslashes(strip_tags($_POST['phone']));
} else {$email = 'No phone entered';}

if ((isset($_POST['msg'])) && (strlen(trim($_POST['msg'])) > 0)) {
	$msg= stripslashes(strip_tags($_POST['msg']));
} else {$email = 'No msg entered';}



 $to="gittaau@yahoo.com.au";

   $subject="Massage Therapy Perth";

   
   $from = stripslashes('gittaau@yahoo.com.au')."<".stripslashes('gittaau@yahoo.com.au').">";
$from ="Massage Therapy Perth";
   // generate a random string to be used as the boundary marker
   $mime_boundary="==Multipart_Boundary_x".md5(mt_rand())."x";




  $message = '<table width="550" border="0" cellspacing="0" cellpadding="0" style="border:2px solid #641866" bgcolor="#641866">
 <tr style="height:25px; font-size:14px; color:#FFFFFF;"><td><strong>Massage Therapy Perth</strong>
 </td></tr>
  <tr>
    <td>
<table width="550" border="0" cellspacing="2" cellpadding="2" bgcolor="#be99be" style="border:1px solid #536D27" >
  <tr bgcolor="#eeffee">
    <td>First Name</td>
    <td>'.$fname.'</td>
  </tr>
 <tr bgcolor="#eeffee">
    <td>Last Name</td>
    <td>'.$lname.'</td>
  </tr>
   <tr bgcolor="#eeffee">
    <td>Email</td>
    <td>'.$email.'</td>
  </tr>
 <tr bgcolor="#eeffee">
    <td>Phone</td>
    <td>'.$phone.'</td>
  </tr>
 <tr bgcolor="#eeffee">
    <td>Massage</td>
    <td>'.$msg.'</td>
  </tr>
   </table></td>
  </tr>
</table>';
 
  
  
  


         // now we encode it and split it into acceptable length lines
         $data = chunk_split(base64_encode($data));
    // }

      // now we'll build the message headers
      $headers = "From: $from\r\n" .
         "MIME-Version: 1.0\r\n" .
         "Content-Type: multipart/mixed;\r\n" .
         " boundary=\"{$mime_boundary}\"";


      $message = "This is a multi-part message in MIME format.\n\n" .
         "--{$mime_boundary}\n" .
         "Content-Type: text/html; charset=\"iso-8859-1\"\n" .
         "Content-Transfer-Encoding: 7bit\n\n" .
         $message . "\n\n";

      
      $message .= "--{$mime_boundary}\n" .
         "Content-Type: {$type};\n" .
         " name=\"{$name}\"\n" .

         "Content-Transfer-Encoding: base64\n\n" .
         $data . "\n\n" .
         "--{$mime_boundary}--\n";

      // now we just send the message
      if (@mail($to , $subject, $message, $headers))
         echo "Message Sent";
      else
         echo "Failed to send";
 //  }  
//exit;
  header("Location: thanks.html"); 
?>